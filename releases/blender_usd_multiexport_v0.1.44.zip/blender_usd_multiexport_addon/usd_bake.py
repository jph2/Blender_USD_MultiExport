from __future__ import annotations

from typing import Any, Dict, Optional


def bake_usd_geometry(
    filepath: str,
    scale_factor: float,
    y_is_up: bool,
    meters_per_unit: float,
    logger=None,
    start_point_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Bake scale/rotation into USD mesh geometry and set stage metadata.

    This is a post-process step that:
    - Applies rotation (Z-up -> Y-up) and scale directly to mesh points
    - Rotates normals only (no scaling), then normalizes
    - Clears xformOps to keep files clean
    - Sets metersPerUnit and upAxis to match baked geometry
    """
    context = start_point_context or {}
    result: Dict[str, Any] = {
        "success": False,
        "scale_factor": scale_factor,
        "y_is_up": y_is_up,
        "meters_per_unit": meters_per_unit,
        "meshes_processed": 0,
        "points_baked": 0,
        "normals_baked": 0,
        "xforms_cleared": 0,
    }

    try:
        from pxr import Usd, UsdGeom, Gf
    except ImportError:
        if logger:
            logger.log_warning(
                "USD Python API (pxr) not available. Bake step skipped.",
                context=context,
            )
        result["reason"] = "pxr_unavailable"
        return result

    stage = Usd.Stage.Open(filepath)
    if not stage:
        if logger:
            logger.log_warning(
                f"Could not open USD stage for baking: {filepath}",
                context=context,
            )
        result["reason"] = "stage_open_failed"
        return result

    # Build bake matrices
    rotation_matrix = Gf.Matrix4d(1.0)
    if y_is_up:
        rotation = Gf.Rotation(Gf.Vec3d(1.0, 0.0, 0.0), -90.0)
        rotation_matrix.SetRotate(rotation)

    scale_matrix = Gf.Matrix4d(1.0)
    if scale_factor != 1.0:
        scale_matrix.SetScale(
            Gf.Vec3d(scale_factor, scale_factor, scale_factor)
        )

    # Apply rotation first, then scale
    bake_matrix = scale_matrix * rotation_matrix

    for prim in stage.Traverse():
        if not prim.IsA(UsdGeom.Mesh):
            continue

        mesh = UsdGeom.Mesh(prim)

        points_attr = mesh.GetPointsAttr()
        points = points_attr.Get()
        if points:
            baked_points = []
            for point in points:
                p4 = Gf.Vec4d(point[0], point[1], point[2], 1.0)
                p4_baked = bake_matrix * p4
                baked_points.append(
                    Gf.Vec3f(p4_baked[0], p4_baked[1], p4_baked[2])
                )
            points_attr.Set(baked_points)
            result["points_baked"] += len(baked_points)

        normals_attr = mesh.GetNormalsAttr()
        normals = normals_attr.Get()
        if normals:
            baked_normals = []
            for normal in normals:
                n4 = Gf.Vec4d(normal[0], normal[1], normal[2], 0.0)
                n4_baked = rotation_matrix * n4
                n3 = Gf.Vec3f(n4_baked[0], n4_baked[1], n4_baked[2])
                try:
                    n3.Normalize()
                except Exception:
                    pass
                baked_normals.append(n3)
            normals_attr.Set(baked_normals)
            result["normals_baked"] += len(baked_normals)

        result["meshes_processed"] += 1

    for prim in stage.Traverse():
        if prim.IsA(UsdGeom.Xformable):
            xformable = UsdGeom.Xformable(prim)
            xformable.ClearXformOpOrder()
            result["xforms_cleared"] += 1

    UsdGeom.SetStageMetersPerUnit(stage, meters_per_unit)
    UsdGeom.SetStageUpAxis(
        stage, UsdGeom.Tokens.y if y_is_up else UsdGeom.Tokens.z
    )

    stage.Save()
    result["success"] = True
    return result
