from __future__ import annotations

import os
import re
from typing import Any, Dict, Optional


def bake_usd_geometry(
    filepath: str,
    scale_factor: float,
    y_is_up: bool,
    meters_per_unit: float,
    logger=None,
    start_point_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Bake scale/rotation into USD mesh geometry and set stage metadata.

    v0.1.70: Fixed to preserve spatial positions for collections.
    
    This is a post-process step that:
    - Applies rotation (Z-up -> Y-up) and scale directly to mesh points (LOCAL coords only)
    - Rotates normals only (no scaling), then normalizes
    - Updates xformOp values (scale translate, rotate orientation) instead of clearing them
    - Sets metersPerUnit and upAxis to match baked geometry
    """
    context = start_point_context or {}
    result: Dict[str, Any] = {
        "success": False,
        "scale_factor": scale_factor,
        "y_is_up": y_is_up,
        "meters_per_unit": meters_per_unit,
        "meshes_processed": 0,
        "points_baked": 0,
        "normals_baked": 0,
        "xforms_updated": 0,
    }

    try:
        from pxr import Usd, UsdGeom, Gf
    except ImportError:
        if logger:
            logger.log_warning(
                "USD Python API (pxr) not available. Bake step skipped.",
                context=context,
            )
        result["reason"] = "pxr_unavailable"
        return result

    stage = Usd.Stage.Open(filepath)
    if not stage:
        if logger:
            logger.log_warning(
                f"Could not open USD stage for baking: {filepath}",
                context=context,
            )
        result["reason"] = "stage_open_failed"
        return result

    # Build transformation matrix for LOCAL geometry
    # v0.1.71: Apply BOTH scale AND rotation to geometry
    # Scale: meters → centimeters (100x)
    # Rotation: Z-up → Y-up (+90° around X, not -90° which caused flip)
    
    rotation_matrix = Gf.Matrix4d(1.0)
    if y_is_up:
        # +90° around X: Z-up (0,0,1) → Y-up (0,1,0)
        # This maps: X→X, Y→-Z, Z→Y
        rotation = Gf.Rotation(Gf.Vec3d(1.0, 0.0, 0.0), 90.0)
        rotation_matrix.SetRotate(rotation)

    scale_matrix = Gf.Matrix4d(1.0)
    if scale_factor != 1.0:
        scale_matrix.SetScale(Gf.Vec3d(scale_factor, scale_factor, scale_factor))

    # v0.1.71: Apply rotation first, then scale to LOCAL geometry
    # This scales the geometry to target units (cm) and rotates coordinate system
    local_bake_matrix = scale_matrix * rotation_matrix

    xform_prims_processed = set()

    for prim in stage.Traverse():
        if not prim.IsA(UsdGeom.Mesh):
            continue

        mesh = UsdGeom.Mesh(prim)
        
        # v0.1.70: Only bake rotation into LOCAL points (not world transform)
        # The scale will be applied to xformOps to preserve positions
        points_attr = mesh.GetPointsAttr()
        points = points_attr.Get()
        if points:
            baked_points = []
            for point in points:
                p4 = Gf.Vec4d(point[0], point[1], point[2], 1.0)
                p4_baked = local_bake_matrix * p4
                baked_points.append(
                    Gf.Vec3f(p4_baked[0], p4_baked[1], p4_baked[2])
                )
            points_attr.Set(baked_points)
            result["points_baked"] += len(baked_points)

        normals_attr = mesh.GetNormalsAttr()
        normals = normals_attr.Get()
        if normals:
            row0 = local_bake_matrix.GetRow(0)
            row1 = local_bake_matrix.GetRow(1)
            row2 = local_bake_matrix.GetRow(2)
            normal_matrix = Gf.Matrix3d(
                row0[0], row0[1], row0[2],
                row1[0], row1[1], row1[2],
                row2[0], row2[1], row2[2],
            )
            try:
                normal_matrix = normal_matrix.GetInverse().GetTranspose()
            except Exception:
                pass
            baked_normals = []
            for normal in normals:
                n3 = Gf.Vec3d(normal[0], normal[1], normal[2])
                n3 = normal_matrix * n3
                n3 = Gf.Vec3f(n3[0], n3[1], n3[2])
                try:
                    n3.Normalize()
                except Exception:
                    pass
                baked_normals.append(n3)
            normals_attr.Set(baked_normals)
            result["normals_baked"] += len(baked_normals)

        result["meshes_processed"] += 1
        
        # v0.1.70: Update xformOps on ancestors instead of clearing them
        ancestor = prim
        while ancestor and not ancestor.IsPseudoRoot():
            if ancestor not in xform_prims_processed:
                xformable = UsdGeom.Xformable(ancestor)
                if xformable:
                    _update_xform_ops(xformable, scale_factor, y_is_up, Gf)
                    xform_prims_processed.add(ancestor)
                    result["xforms_updated"] += 1
            ancestor = ancestor.GetParent()

    UsdGeom.SetStageMetersPerUnit(stage, meters_per_unit)
    UsdGeom.SetStageUpAxis(
        stage, UsdGeom.Tokens.y if y_is_up else UsdGeom.Tokens.z
    )

    try:
        stage.Save()
    except Exception as exc:
        result["reason"] = "stage_save_failed"
        result["exception"] = str(exc)
        if logger:
            logger.log_warning(
                "USD bake failed to save stage. File may be locked.",
                context={**context, "exception": str(exc), "filepath": filepath},
            )
        _cleanup_temp_usd_file(str(exc), logger, context)
        return result

    result["success"] = True
    return result


def _update_xform_ops(xformable, scale_factor: float, y_is_up: bool, Gf) -> None:
    """Update xformOp values to account for scale and coordinate conversion.
    
    v0.1.72: Added TypeScale handling - swap Y/Z without negation.
    
    For Z-up to Y-up conversion:
    - Translate (x, y, z) -> (x*s, z*s, -y*s) - position conversion with scale
    - Scale (sx, sy, sz) -> (sx, sz, sy) - swap Y/Z, NO negation!
    - Rotation angles need axis swapping
    """
    xform_ops = xformable.GetOrderedXformOps()
    
    for op in xform_ops:
        op_type = op.GetOpType()
        
        # Handle translate ops - need coordinate conversion AND unit scale
        if op_type == op.TypeTranslate:
            translate = op.Get()
            if translate is not None:
                x, y, z = translate[0], translate[1], translate[2]
                if y_is_up:
                    # Z-up (x, y, z) -> Y-up: X→X, Y→-Z, Z→Y
                    new_x = x * scale_factor
                    new_y = z * scale_factor   # Z becomes Y (up)
                    new_z = -y * scale_factor  # Y becomes -Z
                    op.Set(Gf.Vec3d(new_x, new_y, new_z))
                elif scale_factor != 1.0:
                    # Just scale, no rotation
                    op.Set(Gf.Vec3d(x * scale_factor, y * scale_factor, z * scale_factor))
        
        # Handle scale ops - swap Y/Z axes but DO NOT NEGATE!
        # v0.1.72: Scale is NOT a direction vector, just axis magnitudes
        elif op_type == op.TypeScale:
            scale = op.Get()
            if scale is not None and y_is_up:
                sx, sy, sz = scale[0], scale[1], scale[2]
                # Swap Y and Z scale values (no negation!)
                # Z-up scale (sx, sy, sz) -> Y-up scale (sx, sz, sy)
                op.Set(Gf.Vec3f(sx, sz, sy))
        
        # Handle rotateXYZ ops - convert rotation angles for Y-up
        elif op_type == op.TypeRotateXYZ:
            rotation = op.Get()
            if rotation is not None and y_is_up:
                rx, ry, rz = rotation[0], rotation[1], rotation[2]
                # For +90° around X coord conversion: swap Y/Z rotations
                # X rotation stays, Y rot → -Z rot, Z rot → Y rot
                new_rx = rx
                new_ry = rz   # Z rotation becomes Y rotation
                new_rz = -ry  # Y rotation becomes -Z rotation
                op.Set(Gf.Vec3f(new_rx, new_ry, new_rz))
        
        # Handle orient ops (quaternion) - conjugate transform for Y-up
        elif op_type == op.TypeOrient:
            quat = op.Get()
            if quat is not None and y_is_up:
                # Convert quaternion: for +90° around X
                # Swap y and z imaginary components, negate old y
                w = quat.GetReal()
                img = quat.GetImaginary()
                x, y, z = img[0], img[1], img[2]
                new_quat = Gf.Quatd(w, Gf.Vec3d(x, z, -y))
                new_quat.Normalize()
                op.Set(new_quat)
        
        # Handle transform (matrix4d) ops
        elif op_type == op.TypeTransform:
            matrix = op.Get()
            if matrix is not None:
                # Build conversion matrix with +90° around X (not -90°)
                if y_is_up:
                    rot = Gf.Rotation(Gf.Vec3d(1.0, 0.0, 0.0), 90.0)
                    conv_matrix = Gf.Matrix4d(1.0)
                    conv_matrix.SetRotate(rot)
                else:
                    conv_matrix = Gf.Matrix4d(1.0)
                
                if scale_factor != 1.0:
                    scale_matrix = Gf.Matrix4d(1.0)
                    scale_matrix.SetScale(Gf.Vec3d(scale_factor, scale_factor, scale_factor))
                    conv_matrix = scale_matrix * conv_matrix
                
                # Apply conversion
                new_matrix = conv_matrix * matrix
                op.Set(new_matrix)


def _cleanup_temp_usd_file(message: str, logger, context: Dict[str, Any]) -> None:
    match = re.search(r"temporary file '([^']+)' to", message)
    if not match:
        return
    temp_path = match.group(1)
    try:
        if os.path.exists(temp_path):
            os.remove(temp_path)
            if logger:
                logger.log_info(
                    "Removed temporary USD file after save failure.",
                    context={**context, "temp_path": temp_path},
                )
    except Exception as exc:
        if logger:
            logger.log_warning(
                "Failed to remove temporary USD file.",
                context={
                    **context,
                    "temp_path": temp_path,
                    "exception": str(exc),
                },
            )
