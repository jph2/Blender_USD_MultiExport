from __future__ import annotations

import os
import re
from typing import Any, Dict, Optional


def bake_usd_geometry(
    filepath: str,
    scale_factor: float,
    y_is_up: bool,
    meters_per_unit: float,
    logger=None,
    start_point_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Bake scale and coordinate conversion into USD stage.

    v0.1.80: Simplified algorithm based on v0.1.75 with normalization.
    
    The algorithm is simple:
    1. Scale mesh points for unit conversion (meters → centimeters)
    2. Rotate child TRANSLATES by -90° X (around world origin 0,0,0)
    3. DO NOT touch child rotations - leave them exactly as-is
    4. Set default prim to identity transform
    
    This "normalizes" the Z-up → Y-up conversion by baking it into
    child positions while leaving their local rotations unchanged.
    """
    context = start_point_context or {}
    result: Dict[str, Any] = {
        "success": False,
        "scale_factor": scale_factor,
        "y_is_up": y_is_up,
        "meters_per_unit": meters_per_unit,
        "meshes_processed": 0,
        "points_scaled": 0,
        "translates_rotated": 0,
        "transform_flattened": False,
    }

    try:
        from pxr import Usd, UsdGeom, Gf
    except ImportError:
        if logger:
            logger.log_warning(
                "USD Python API (pxr) not available. Bake step skipped.",
                context=context,
            )
        result["reason"] = "pxr_unavailable"
        return result

    stage = Usd.Stage.Open(filepath)
    if not stage:
        if logger:
            logger.log_warning(
                f"Could not open USD stage for baking: {filepath}",
                context=context,
            )
        result["reason"] = "stage_open_failed"
        return result

    # Build the -90° X rotation matrix for Z-up → Y-up conversion
    rotation = Gf.Rotation(Gf.Vec3d(1, 0, 0), -90.0)
    rotation_matrix = Gf.Matrix4d(1.0)
    rotation_matrix.SetRotate(rotation)

    # Step 1: Scale mesh points for unit conversion ONLY
    # NO rotation here - geometry stays in its local space
    for prim in stage.Traverse():
        if prim.IsA(UsdGeom.Mesh):
            mesh = UsdGeom.Mesh(prim)
            
            points_attr = mesh.GetPointsAttr()
            points = points_attr.Get()
            if points and scale_factor != 1.0:
                scaled_points = []
                for point in points:
                    scaled_points.append(Gf.Vec3f(
                        point[0] * scale_factor,
                        point[1] * scale_factor,
                        point[2] * scale_factor
                    ))
                points_attr.Set(scaled_points)
                result["points_scaled"] += len(scaled_points)

            result["meshes_processed"] += 1

    # Step 2: Rotate child TRANSLATES and scale them for units
    # DO NOT touch child rotations!
    default_prim = stage.GetDefaultPrim()
    if default_prim and default_prim.IsValid():
        for child_prim in default_prim.GetChildren():
            child_xformable = UsdGeom.Xformable(child_prim)
            if not child_xformable:
                continue
            
            xform_ops = child_xformable.GetOrderedXformOps()
            
            # Extract current values
            child_translate = Gf.Vec3d(0, 0, 0)
            child_rotation = Gf.Vec3f(0, 0, 0)
            child_scale = Gf.Vec3f(1, 1, 1)
            
            for op in xform_ops:
                op_type = op.GetOpType()
                if op_type == UsdGeom.XformOp.TypeTranslate:
                    t = op.Get()
                    if t:
                        child_translate = Gf.Vec3d(t[0], t[1], t[2])
                elif op_type == UsdGeom.XformOp.TypeRotateXYZ:
                    r = op.Get()
                    if r:
                        child_rotation = Gf.Vec3f(r[0], r[1], r[2])
                elif op_type == UsdGeom.XformOp.TypeScale:
                    s = op.Get()
                    if s:
                        child_scale = Gf.Vec3f(s[0], s[1], s[2])
            
            # Scale translate for unit conversion, then rotate for coordinate conversion
            scaled_translate = Gf.Vec3d(
                child_translate[0] * scale_factor,
                child_translate[1] * scale_factor,
                child_translate[2] * scale_factor
            )
            
            if y_is_up:
                # Rotate translate around world origin (0,0,0) by -90° X
                rotated_translate = rotation_matrix.Transform(scaled_translate)
                result["translates_rotated"] += 1
            else:
                rotated_translate = scaled_translate
            
            # Rebuild xformOps with new translate but UNCHANGED rotation
            child_xformable.ClearXformOpOrder()
            
            new_translate_op = child_xformable.AddTranslateOp()
            new_translate_op.Set(rotated_translate)
            
            new_rotate_op = child_xformable.AddRotateXYZOp()
            new_rotate_op.Set(child_rotation)  # UNCHANGED - this is the key!
            
            new_scale_op = child_xformable.AddScaleOp()
            new_scale_op.Set(child_scale)  # UNCHANGED

        # Step 3: Set default prim to IDENTITY (the rotation is now "baked" into children)
        default_xformable = UsdGeom.Xformable(default_prim)
        if default_xformable:
            default_xformable.ClearXformOpOrder()
            t_op = default_xformable.AddTranslateOp()
            t_op.Set(Gf.Vec3d(0, 0, 0))
            r_op = default_xformable.AddRotateXYZOp()
            r_op.Set(Gf.Vec3f(0, 0, 0))  # Identity - rotation "normalized"
            s_op = default_xformable.AddScaleOp()
            s_op.Set(Gf.Vec3f(1, 1, 1))
            result["transform_flattened"] = True

    # Set stage metadata
    UsdGeom.SetStageMetersPerUnit(stage, meters_per_unit)
    UsdGeom.SetStageUpAxis(
        stage, UsdGeom.Tokens.y if y_is_up else UsdGeom.Tokens.z
    )

    try:
        stage.Save()
    except Exception as exc:
        result["reason"] = "stage_save_failed"
        result["exception"] = str(exc)
        if logger:
            logger.log_warning(
                "USD bake failed to save stage. File may be locked.",
                context={**context, "exception": str(exc), "filepath": filepath},
            )
        _cleanup_temp_usd_file(str(exc), logger, context)
        return result

    result["success"] = True
    return result


def _cleanup_temp_usd_file(message: str, logger, context: Dict[str, Any]) -> None:
    match = re.search(r"temporary file '([^']+)' to", message)
    if not match:
        return
    temp_path = match.group(1)
    try:
        if os.path.exists(temp_path):
            os.remove(temp_path)
            if logger:
                logger.log_info(
                    "Removed temporary USD file after save failure.",
                    context={**context, "temp_path": temp_path},
                )
    except Exception as exc:
        if logger:
            logger.log_warning(
                "Failed to remove temporary USD file.",
                context={
                    **context,
                    "temp_path": temp_path,
                    "exception": str(exc),
                },
            )
