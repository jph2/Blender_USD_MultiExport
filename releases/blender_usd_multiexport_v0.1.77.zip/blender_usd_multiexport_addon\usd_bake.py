from __future__ import annotations

import os
import re
from typing import Any, Dict, Optional


def bake_usd_geometry(
    filepath: str,
    scale_factor: float,
    y_is_up: bool,
    meters_per_unit: float,
    logger=None,
    start_point_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Bake scale into geometry and flatten parent rotation onto children.

    v0.1.77: CORRECT FLATTEN approach per USD NIM guidance.
    
    Key insight: DON'T rotate mesh points! Instead:
    1. Scale mesh points by scale_factor (unit conversion only)
    2. Rotate child TRANSLATES around world origin (0,0,0)
    3. COMBINE parent rotation WITH child rotation xformOps
    4. Reset default prim to IDENTITY
    
    This preserves geometry integrity while correctly positioning objects.
    """
    context = start_point_context or {}
    result: Dict[str, Any] = {
        "success": False,
        "scale_factor": scale_factor,
        "y_is_up": y_is_up,
        "meters_per_unit": meters_per_unit,
        "meshes_processed": 0,
        "points_scaled": 0,
        "translates_rotated": 0,
        "rotations_combined": 0,
        "transform_flattened": False,
    }

    try:
        from pxr import Usd, UsdGeom, Gf
    except ImportError:
        if logger:
            logger.log_warning(
                "USD Python API (pxr) not available. Bake step skipped.",
                context=context,
            )
        result["reason"] = "pxr_unavailable"
        return result

    stage = Usd.Stage.Open(filepath)
    if not stage:
        if logger:
            logger.log_warning(
                f"Could not open USD stage for baking: {filepath}",
                context=context,
            )
        result["reason"] = "stage_open_failed"
        return result

    # v0.1.77: Build rotation matrix for coordinate conversion (Z-up → Y-up)
    # This is used for TRANSLATES and child ROTATIONS, NOT for geometry points
    parent_rotation = Gf.Rotation()
    if y_is_up:
        parent_rotation = Gf.Rotation(Gf.Vec3d(1, 0, 0), -90.0)
    
    rotation_matrix = Gf.Matrix4d(1.0)
    rotation_matrix.SetRotate(parent_rotation)

    # v0.1.77: Scale-only matrix for geometry (NO rotation on geometry!)
    scale_matrix = Gf.Matrix4d(1.0)
    if scale_factor != 1.0:
        scale_matrix.SetScale(Gf.Vec3d(scale_factor, scale_factor, scale_factor))

    default_prim = stage.GetDefaultPrim()
    
    # v0.1.77: Scale mesh points ONLY (no rotation - that goes on xformOps)
    for prim in stage.Traverse():
        if prim.IsA(UsdGeom.Mesh):
            mesh = UsdGeom.Mesh(prim)
            
            # Scale points for unit conversion (meters → centimeters)
            # DO NOT ROTATE - rotation is handled via xformOps
            points_attr = mesh.GetPointsAttr()
            points = points_attr.Get()
            if points and scale_factor != 1.0:
                scaled_points = []
                for point in points:
                    scaled_points.append(Gf.Vec3f(
                        point[0] * scale_factor,
                        point[1] * scale_factor,
                        point[2] * scale_factor
                    ))
                points_attr.Set(scaled_points)
                result["points_scaled"] += len(scaled_points)

            result["meshes_processed"] += 1

    # v0.1.77: Flatten parent rotation onto children (per USD NIM guidance)
    if default_prim and default_prim.IsValid():
        for child_prim in default_prim.GetChildren():
            child_xformable = UsdGeom.Xformable(child_prim)
            if not child_xformable:
                continue
            
            # Get current child xformOps
            xform_ops = child_xformable.GetOrderedXformOps()
            
            child_translate = Gf.Vec3d(0, 0, 0)
            child_rotation = Gf.Vec3f(0, 0, 0)
            has_translate = False
            has_rotation = False
            
            for op in xform_ops:
                if op.GetOpType() == UsdGeom.XformOp.TypeTranslate:
                    t = op.Get()
                    if t:
                        child_translate = Gf.Vec3d(t[0], t[1], t[2])
                        has_translate = True
                elif op.GetOpType() == UsdGeom.XformOp.TypeRotateXYZ:
                    r = op.Get()
                    if r:
                        child_rotation = Gf.Vec3f(r[0], r[1], r[2])
                        has_rotation = True
            
            # Rotate child's WORLD POSITION around origin (0,0,0)
            if y_is_up:
                # Scale first, then rotate the position
                scaled_translate = Gf.Vec3d(
                    child_translate[0] * scale_factor,
                    child_translate[1] * scale_factor,
                    child_translate[2] * scale_factor
                )
                rotated_translate = rotation_matrix.Transform(scaled_translate)
                result["translates_rotated"] += 1
            else:
                rotated_translate = Gf.Vec3d(
                    child_translate[0] * scale_factor,
                    child_translate[1] * scale_factor,
                    child_translate[2] * scale_factor
                )
            
            # Combine parent rotation with child's existing rotation
            # Parent rotation: -90° around X
            # New child rotation = parent_rotation + child_rotation (simplified for XYZ euler)
            if y_is_up:
                combined_rotation = Gf.Vec3f(
                    -90.0 + child_rotation[0],  # Add parent's X rotation
                    child_rotation[1],
                    child_rotation[2]
                )
                result["rotations_combined"] += 1
            else:
                combined_rotation = child_rotation
            
            # Clear and rebuild child xformOps with flattened values
            child_xformable.ClearXformOpOrder()
            
            new_translate_op = child_xformable.AddTranslateOp()
            new_translate_op.Set(rotated_translate)
            
            new_rotate_op = child_xformable.AddRotateXYZOp()
            new_rotate_op.Set(combined_rotation)
            
            # Preserve scale if it existed
            new_scale_op = child_xformable.AddScaleOp()
            new_scale_op.Set(Gf.Vec3f(1, 1, 1))

        # Reset default prim to IDENTITY
        default_xformable = UsdGeom.Xformable(default_prim)
        if default_xformable:
            default_xformable.ClearXformOpOrder()
            t_op = default_xformable.AddTranslateOp()
            t_op.Set(Gf.Vec3d(0, 0, 0))
            r_op = default_xformable.AddRotateXYZOp()
            r_op.Set(Gf.Vec3f(0, 0, 0))
            s_op = default_xformable.AddScaleOp()
            s_op.Set(Gf.Vec3f(1, 1, 1))
            result["transform_flattened"] = True

    UsdGeom.SetStageMetersPerUnit(stage, meters_per_unit)
    UsdGeom.SetStageUpAxis(
        stage, UsdGeom.Tokens.y if y_is_up else UsdGeom.Tokens.z
    )

    try:
        stage.Save()
    except Exception as exc:
        result["reason"] = "stage_save_failed"
        result["exception"] = str(exc)
        if logger:
            logger.log_warning(
                "USD bake failed to save stage. File may be locked.",
                context={**context, "exception": str(exc), "filepath": filepath},
            )
        _cleanup_temp_usd_file(str(exc), logger, context)
        return result

    result["success"] = True
    return result


def _flatten_nested_children(parent_prim, rotation_matrix, scale_factor, y_is_up, Gf, UsdGeom) -> int:
    """Recursively flatten transforms for nested children (grandchildren, etc.).
    
    v0.1.77: Handle prims that are not direct children of the default prim.
    """
    count = 0
    for child_prim in parent_prim.GetChildren():
        child_xformable = UsdGeom.Xformable(child_prim)
        if not child_xformable:
            continue
        
        # Process this child's xformOps
        xform_ops = child_xformable.GetOrderedXformOps()
        for op in xform_ops:
            if op.GetOpType() == UsdGeom.XformOp.TypeTranslate:
                t = op.Get()
                if t:
                    # Scale and rotate translate
                    scaled = Gf.Vec3d(t[0] * scale_factor, t[1] * scale_factor, t[2] * scale_factor)
                    if y_is_up:
                        rotated = rotation_matrix.Transform(scaled)
                        op.Set(Gf.Vec3d(rotated[0], rotated[1], rotated[2]))
                    else:
                        op.Set(scaled)
                    count += 1
        
        # Recurse into grandchildren
        count += _flatten_nested_children(child_prim, rotation_matrix, scale_factor, y_is_up, Gf, UsdGeom)
    
    return count


def _cleanup_temp_usd_file(message: str, logger, context: Dict[str, Any]) -> None:
    match = re.search(r"temporary file '([^']+)' to", message)
    if not match:
        return
    temp_path = match.group(1)
    try:
        if os.path.exists(temp_path):
            os.remove(temp_path)
            if logger:
                logger.log_info(
                    "Removed temporary USD file after save failure.",
                    context={**context, "temp_path": temp_path},
                )
    except Exception as exc:
        if logger:
            logger.log_warning(
                "Failed to remove temporary USD file.",
                context={
                    **context,
                    "temp_path": temp_path,
                    "exception": str(exc),
                },
            )
