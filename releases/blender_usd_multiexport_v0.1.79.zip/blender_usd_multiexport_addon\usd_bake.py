from __future__ import annotations

import math
import os
import re
from typing import Any, Dict, Optional


def bake_usd_geometry(
    filepath: str,
    scale_factor: float,
    y_is_up: bool,
    meters_per_unit: float,
    logger=None,
    start_point_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Bake scale into geometry and flatten parent rotation onto children.

    v0.1.79: Fixed Euler rotation composition order.
    
    Key fixes from v0.1.77:
    1. Use proper quaternion/matrix composition for rotations (NOT Euler addition!)
    2. Process nested children recursively
    3. Scale mesh points for unit conversion only
    4. Rotate child TRANSLATES around world origin (0,0,0)
    5. Reset default prim to IDENTITY
    
    The v0.1.77 bug was using simple Euler addition which is mathematically wrong:
      combined = (-90 + child_x, child_y, child_z)  # WRONG!
    
    Correct approach uses rotation matrix composition:
      combined_rotation = parent_rotation * child_rotation  # Matrix multiplication
    """
    context = start_point_context or {}
    result: Dict[str, Any] = {
        "success": False,
        "scale_factor": scale_factor,
        "y_is_up": y_is_up,
        "meters_per_unit": meters_per_unit,
        "meshes_processed": 0,
        "points_scaled": 0,
        "translates_rotated": 0,
        "rotations_combined": 0,
        "nested_children_processed": 0,
        "transform_flattened": False,
    }

    try:
        from pxr import Usd, UsdGeom, Gf
    except ImportError:
        if logger:
            logger.log_warning(
                "USD Python API (pxr) not available. Bake step skipped.",
                context=context,
            )
        result["reason"] = "pxr_unavailable"
        return result

    stage = Usd.Stage.Open(filepath)
    if not stage:
        if logger:
            logger.log_warning(
                f"Could not open USD stage for baking: {filepath}",
                context=context,
            )
        result["reason"] = "stage_open_failed"
        return result

    # v0.1.78: Build parent rotation for Z-up → Y-up conversion
    # This will be composed with child rotations using proper matrix math
    parent_rotation = Gf.Rotation()
    if y_is_up:
        parent_rotation = Gf.Rotation(Gf.Vec3d(1, 0, 0), -90.0)
    
    rotation_matrix = Gf.Matrix4d(1.0)
    rotation_matrix.SetRotate(parent_rotation)

    default_prim = stage.GetDefaultPrim()
    
    # Step 1: Scale mesh points ONLY (no rotation - that's handled via xformOps)
    for prim in stage.Traverse():
        if prim.IsA(UsdGeom.Mesh):
            mesh = UsdGeom.Mesh(prim)
            
            # Scale points for unit conversion (meters → centimeters)
            points_attr = mesh.GetPointsAttr()
            points = points_attr.Get()
            if points and scale_factor != 1.0:
                scaled_points = []
                for point in points:
                    scaled_points.append(Gf.Vec3f(
                        point[0] * scale_factor,
                        point[1] * scale_factor,
                        point[2] * scale_factor
                    ))
                points_attr.Set(scaled_points)
                result["points_scaled"] += len(scaled_points)

            result["meshes_processed"] += 1

    # Step 2: Flatten parent rotation onto all children
    if default_prim and default_prim.IsValid():
        for child_prim in default_prim.GetChildren():
            _flatten_child_transform(
                child_prim, parent_rotation, rotation_matrix, 
                scale_factor, y_is_up, Gf, UsdGeom, result
            )
        
        # Step 3: Process nested children (grandchildren, etc.)
        for child_prim in default_prim.GetChildren():
            nested_count = _flatten_nested_children(
                child_prim, rotation_matrix, scale_factor, y_is_up, Gf, UsdGeom
            )
            result["nested_children_processed"] += nested_count

        # Step 4: Reset default prim to IDENTITY
        default_xformable = UsdGeom.Xformable(default_prim)
        if default_xformable:
            default_xformable.ClearXformOpOrder()
            t_op = default_xformable.AddTranslateOp()
            t_op.Set(Gf.Vec3d(0, 0, 0))
            r_op = default_xformable.AddRotateXYZOp()
            r_op.Set(Gf.Vec3f(0, 0, 0))
            s_op = default_xformable.AddScaleOp()
            s_op.Set(Gf.Vec3f(1, 1, 1))
            result["transform_flattened"] = True

    UsdGeom.SetStageMetersPerUnit(stage, meters_per_unit)
    UsdGeom.SetStageUpAxis(
        stage, UsdGeom.Tokens.y if y_is_up else UsdGeom.Tokens.z
    )

    try:
        stage.Save()
    except Exception as exc:
        result["reason"] = "stage_save_failed"
        result["exception"] = str(exc)
        if logger:
            logger.log_warning(
                "USD bake failed to save stage. File may be locked.",
                context={**context, "exception": str(exc), "filepath": filepath},
            )
        _cleanup_temp_usd_file(str(exc), logger, context)
        return result

    result["success"] = True
    return result


def _flatten_child_transform(
    child_prim, parent_rotation, rotation_matrix, scale_factor, y_is_up, Gf, UsdGeom, result
):
    """Flatten parent rotation onto a single child prim using proper matrix composition.
    
    v0.1.79: Fixed rotation composition order (Rx*Ry*Rz for intrinsic XYZ).
    """
    child_xformable = UsdGeom.Xformable(child_prim)
    if not child_xformable:
        return
    
    # Get current child xformOps
    xform_ops = child_xformable.GetOrderedXformOps()
    
    child_translate = Gf.Vec3d(0, 0, 0)
    child_scale = Gf.Vec3f(1, 1, 1)
    child_rotation_euler = Gf.Vec3f(0, 0, 0)
    
    for op in xform_ops:
        op_type = op.GetOpType()
        if op_type == UsdGeom.XformOp.TypeTranslate:
            t = op.Get()
            if t:
                child_translate = Gf.Vec3d(t[0], t[1], t[2])
        elif op_type == UsdGeom.XformOp.TypeRotateXYZ:
            r = op.Get()
            if r:
                child_rotation_euler = Gf.Vec3f(r[0], r[1], r[2])
        elif op_type == UsdGeom.XformOp.TypeScale:
            s = op.Get()
            if s:
                child_scale = Gf.Vec3f(s[0], s[1], s[2])
    
    # Transform child's WORLD POSITION around origin (0,0,0)
    # First scale, then rotate the position
    scaled_translate = Gf.Vec3d(
        child_translate[0] * scale_factor,
        child_translate[1] * scale_factor,
        child_translate[2] * scale_factor
    )
    
    if y_is_up:
        rotated_translate = rotation_matrix.Transform(scaled_translate)
        result["translates_rotated"] += 1
    else:
        rotated_translate = scaled_translate
    
    # v0.1.78: CORRECT rotation composition using matrices/quaternions
    # NOT simple Euler addition!
    if y_is_up:
        combined_euler = _compose_rotations_xyz(parent_rotation, child_rotation_euler, Gf)
        result["rotations_combined"] += 1
    else:
        combined_euler = child_rotation_euler
    
    # Clear and rebuild child xformOps with flattened values
    child_xformable.ClearXformOpOrder()
    
    new_translate_op = child_xformable.AddTranslateOp()
    new_translate_op.Set(rotated_translate)
    
    new_rotate_op = child_xformable.AddRotateXYZOp()
    new_rotate_op.Set(combined_euler)
    
    new_scale_op = child_xformable.AddScaleOp()
    new_scale_op.Set(child_scale)


def _compose_rotations_xyz(parent_rotation, child_euler, Gf):
    """Compose parent rotation with child Euler XYZ rotation using proper matrix math.
    
    v0.1.79: Fixed rotation composition order for intrinsic XYZ Euler angles.
    
    CRITICAL FIX: USD's rotateXYZ uses INTRINSIC Euler angles (rotating around
    local axes), not extrinsic (rotating around fixed world axes).
    
    For intrinsic XYZ: rotate around X, then around the NEW Y, then the NEW Z.
    Matrix composition order: R = Rx * Ry * Rz (multiply in order of application)
    
    v0.1.78 BUG: Used Rz * Ry * Rx (extrinsic order) - WRONG for USD!
    
    Args:
        parent_rotation: Gf.Rotation object for parent (e.g., -90° around X)
        child_euler: Gf.Vec3f of child's Euler angles (rx, ry, rz) in degrees
        Gf: The pxr.Gf module
    
    Returns:
        Gf.Vec3f: Combined Euler XYZ angles in degrees
    """
    # Convert child Euler XYZ to rotation
    rx, ry, rz = child_euler[0], child_euler[1], child_euler[2]
    
    child_rot_x = Gf.Rotation(Gf.Vec3d(1, 0, 0), rx)
    child_rot_y = Gf.Rotation(Gf.Vec3d(0, 1, 0), ry)
    child_rot_z = Gf.Rotation(Gf.Vec3d(0, 0, 1), rz)
    
    # v0.1.79 FIX: Compose in INTRINSIC XYZ order: R = Rx * Ry * Rz
    # This applies X first, then Y around the new axis, then Z around the new axis
    # v0.1.78 BUG was: child_rot_z * child_rot_y * child_rot_x (extrinsic order)
    child_rotation = child_rot_x * child_rot_y * child_rot_z
    
    # Compose parent with child: combined = parent * child
    # This applies parent rotation AFTER child rotation (in world space)
    combined_rotation = parent_rotation * child_rotation
    
    # Convert back to Euler XYZ angles
    combined_euler = _rotation_to_euler_xyz(combined_rotation, Gf)
    
    return Gf.Vec3f(combined_euler[0], combined_euler[1], combined_euler[2])


def _rotation_to_euler_xyz(rotation, Gf):
    """Convert a Gf.Rotation to Euler XYZ angles in degrees.
    
    Args:
        rotation: Gf.Rotation object
        Gf: The pxr.Gf module
    
    Returns:
        tuple: (rx, ry, rz) in degrees
    """
    # Get rotation matrix
    mat = Gf.Matrix3d(rotation)
    
    # Extract Euler XYZ angles from rotation matrix
    # Using standard rotation matrix decomposition for XYZ order
    # R = Rz * Ry * Rx
    #
    # Matrix form:
    # | cy*cz           -cy*sz          sy    |
    # | cx*sz+sx*sy*cz  cx*cz-sx*sy*sz  -sx*cy|
    # | sx*sz-cx*sy*cz  sx*cz+cx*sy*sz  cx*cy |
    
    # Get matrix elements (row, column)
    r00 = mat[0][0]
    r01 = mat[0][1]
    r02 = mat[0][2]
    r10 = mat[1][0]
    r11 = mat[1][1]
    r12 = mat[1][2]
    r20 = mat[2][0]
    r21 = mat[2][1]
    r22 = mat[2][2]
    
    # Check for gimbal lock
    if abs(r02) >= 1.0 - 1e-6:
        # Gimbal lock: ry = +/-90 degrees
        rz = 0.0
        if r02 > 0:
            ry = 90.0
            rx = math.degrees(math.atan2(r10, r11))
        else:
            ry = -90.0
            rx = math.degrees(math.atan2(-r10, r11))
    else:
        ry = math.degrees(math.asin(r02))
        rx = math.degrees(math.atan2(-r12, r22))
        rz = math.degrees(math.atan2(-r01, r00))
    
    return (rx, ry, rz)


def _flatten_nested_children(parent_prim, rotation_matrix, scale_factor, y_is_up, Gf, UsdGeom) -> int:
    """Recursively flatten transforms for nested children (grandchildren, etc.).
    
    v0.1.78: Now actually called from bake_usd_geometry!
    Handles prims that are not direct children of the default prim.
    """
    count = 0
    for child_prim in parent_prim.GetChildren():
        child_xformable = UsdGeom.Xformable(child_prim)
        if not child_xformable:
            # Recurse even if not xformable (might have xformable descendants)
            count += _flatten_nested_children(child_prim, rotation_matrix, scale_factor, y_is_up, Gf, UsdGeom)
            continue
        
        # Process this child's translate xformOps
        xform_ops = child_xformable.GetOrderedXformOps()
        for op in xform_ops:
            if op.GetOpType() == UsdGeom.XformOp.TypeTranslate:
                t = op.Get()
                if t:
                    # Scale and rotate translate
                    scaled = Gf.Vec3d(t[0] * scale_factor, t[1] * scale_factor, t[2] * scale_factor)
                    if y_is_up:
                        rotated = rotation_matrix.Transform(scaled)
                        op.Set(Gf.Vec3d(rotated[0], rotated[1], rotated[2]))
                    else:
                        op.Set(scaled)
                    count += 1
        
        # Recurse into grandchildren
        count += _flatten_nested_children(child_prim, rotation_matrix, scale_factor, y_is_up, Gf, UsdGeom)
    
    return count


def _cleanup_temp_usd_file(message: str, logger, context: Dict[str, Any]) -> None:
    match = re.search(r"temporary file '([^']+)' to", message)
    if not match:
        return
    temp_path = match.group(1)
    try:
        if os.path.exists(temp_path):
            os.remove(temp_path)
            if logger:
                logger.log_info(
                    "Removed temporary USD file after save failure.",
                    context={**context, "temp_path": temp_path},
                )
    except Exception as exc:
        if logger:
            logger.log_warning(
                "Failed to remove temporary USD file.",
                context={
                    **context,
                    "temp_path": temp_path,
                    "exception": str(exc),
                },
            )
